import interact from '@interactjs/interactjs/index';
export default interact;
